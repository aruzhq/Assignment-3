document.addEventListener('DOMContentLoaded', loadPosts);

async function loadPosts() {
    try {
        const response = await fetch('/api/blogs');
        if (!response.ok) throw new Error('Error fetching posts');

        const posts = await response.json();
        const postsContainer = document.getElementById('posts');
        postsContainer.innerHTML = ''; 

        if (posts.length === 0) {
            postsContainer.innerHTML = '<p>No posts available.</p>';
            return;
        }

        posts.forEach(post => {
            const postDiv = document.createElement('div');
            postDiv.classList.add('post');
            const time = post.updatedAt ? post.updatedAt : post.createdAt;
            postDiv.innerHTML = `
                <div class="post-header">
                    <img src="user.png" alt="User Icon" class="user-icon"> 
                    <span class="author-name">${post.author}</span>
                </div>
                <h3>${post.title}</h3>
                <p>${post.body}</p>
                <p class="time"><small>Posted on: ${new Date(time).toLocaleString()}</small></p>
                <button class="update" onclick="updatePost('${post._id}')">Update</button>
                <button class="delete" onclick="deletePost('${post._id}')">Delete</button>
            `;
            postsContainer.appendChild(postDiv);
        });
    } catch (error) {
        console.error(error.message);
    }
}

document.getElementById('blogForm').addEventListener('submit', async (event) => {
    event.preventDefault();
    const title = document.getElementById('title').value;
    const body = document.getElementById('body').value;
    const author = document.getElementById('author').value;

    const response = await fetch('/api/blogs', {
        method: 'POST',
        headers: {
            'Content-Type': 'application/json'
        },
        body: JSON.stringify({ title, body, author })
    });

    if (response.ok) {
        document.getElementById('blogForm').reset(); 
        loadPosts(); 
    } else {
        console.error('Error creating post');
    }
});

async function updatePost(id) {
    const title = prompt("Enter the new title:");
    const body = prompt("Enter the new post text:");
    const author = prompt("Enter the author's name:");

    if (title && body) {
        const response = await fetch(`/api/blogs/${id}`, {
            method: 'PUT',
            headers: {
                'Content-Type': 'application/json'
            },
            body: JSON.stringify({ title, body, author })
        });

        if (response.ok) {
            loadPosts(); 
        } else {
            console.error('Error updating post');
        }
    } else {
        alert("Title and body text are required for editing.");
    }
}

async function deletePost(id) {
    if (confirm("Are you sure you want to delete this post?")) {
        const response = await fetch(`/api/blogs/${id}`, {
            method: 'DELETE'
        });

        if (response.ok) {
            loadPosts();
        } else {
            console.error('Error deleting post');
        }
    }
}
