const express = require('express');
const router = express.Router();
const Blog = require('../models/blog');

router.post('/', async (req, res) => {
    try {
        const { title, body, author } = req.body;

        const newBlog = new Blog({
            title,
            body,
            author,
        });

        const savedBlog = await newBlog.save();
        res.status(201).json(savedBlog);
    } catch (error) {
        res.status(500).json({ message: 'Error creating post', error });
    }
});

router.get('/', async (req, res) => {
    try {
        const blogs = await Blog.find();
        res.status(200).json(blogs);
    } catch (error) {
        res.status(500).json({ message: 'Error retrieving posts', error });
    }
});

router.get('/:id', async (req, res) => {
    try {
        const blog = await Blog.findById(req.params.id);
        if (!blog) return res.status(404).json({ message: 'Post not found' });
        res.status(200).json(blog);
    } catch (error) {
        res.status(500).json({ message: 'Error retrieving post', error });
    }
});

router.put('/:id', async (req, res) => {
    try {
        const { title, body, author } = req.body;
        const updatedBlog = await Blog.findByIdAndUpdate(req.params.id, {
            title,
            body,
            author,
            updatedAt: Date.now() 
        }, { new: true });
        
        if (!updatedBlog) return res.status(404).json({ message: 'Post not found' });
        res.status(200).json(updatedBlog);
    } catch (error) {
        res.status(500).json({ message: 'Error updating post', error });
    }
});

router.delete('/:id', async (req, res) => {
    try {
        const deletedBlog = await Blog.findByIdAndDelete(req.params.id);
        if (!deletedBlog) return res.status(404).json({ message: 'Post not found' });
        res.status(200).json({ message: 'Post deleted successfully' });
    } catch (error) {
        res.status(500).json({ message: 'Error deleting post', error });
    }
});

module.exports = router;
